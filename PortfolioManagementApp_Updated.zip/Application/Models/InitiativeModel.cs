﻿
namespace Application.Models
{
    public class InitiativeModel
    {

        public string PriorityOrder { get; set; }
        
        public string FixVersionName{ get; set; }

        public int ID{ get; set; }

    }
}
